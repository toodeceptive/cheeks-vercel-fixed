# CaterFlow — QA helper
# Usage:
#   $env:BASE_URL="https://<worker>.<acct>.workers.dev"
#   $env:SECRET_SALT="<your secret>"
#   $env:DATE=(node -e "console.log(new Date().toISOString().slice(0,10))")
#   .\QA_HELPER.ps1

Write-Host "BASE_URL=$env:BASE_URL"
Write-Host "DATE=$env:DATE"
node scripts/qa.mjs
