# CaterFlow v10 — Deploy Now (Windows PowerShell)
# Run from the unzipped project folder (the folder that contains wrangler.toml)

# 0) Verify prerequisites
node -v
npm -v

# 1) Install Wrangler CLI
npm i -g wrangler
wrangler -v

# 2) Cloudflare login (opens browser for approval)
wrangler login

# 3) Create R2 bucket (one-time)
wrangler r2 bucket create mint-caterflow-logs

# 4) Generate SECRET_SALT (copy the output)
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# 5) Set required secret (paste the hex when prompted)
wrangler secret put SECRET_SALT

# 6) Install deps and deploy
npm i
wrangler deploy

# 7) After deploy, set these env vars for QA and run it
# Replace <LIVE_URL>, <SECRET_SALT>, <YYYY-MM-DD>
$env:BASE_URL="<LIVE_URL>"
$env:SECRET_SALT="<SECRET_SALT>"
$env:DATE="<YYYY-MM-DD>"
node scripts/qa.mjs
