# CaterFlow — Signed URL generator
# Requires: $env:BASE_URL, $env:SECRET_SALT, $env:DATE

function HmacHex($msg) {
  node -e "const crypto=require('crypto');console.log(crypto.createHmac('sha256',process.env.SECRET_SALT).update('$msg').digest('hex'))"
}

$metricsSig = HmacHex("metrics_date=$env:DATE")
$reportSig  = HmacHex("report_date=$env:DATE")
$inqSig     = HmacHex("logs_inquiries_date=$env:DATE")

Write-Host "METRICS  : $env:BASE_URL/api/metrics?date=$env:DATE&sig=$metricsSig"
Write-Host "REPORT   : $env:BASE_URL/api/report?date=$env:DATE&sig=$reportSig"
Write-Host "INQUIRIES: $env:BASE_URL/api/logs/inquiries?date=$env:DATE&sig=$inqSig"
