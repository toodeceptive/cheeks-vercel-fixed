export function csvEscape(v: string): string {
  const s = (v ?? "").toString();
  return /[",\n\r]/.test(s) ? `\"${s.replace(/\"/g, `\"\"`)}\"` : s;
}

export function textResponse(body: string, status = 200, headers: Record<string, string> = {}) {
  return new Response(body, { status, headers: { "content-type": "text/plain; charset=utf-8", ...headers } });
}

export function jsonResponse(obj: unknown, status = 200, headers: Record<string, string> = {}) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", ...headers },
  });
}

export function redirect(location: string, status: 301 | 302 | 303 = 302, headers: Record<string, string> = {}) {
  return new Response(null, { status, headers: { location, ...headers } });
}

export function setCookieHeader(name: string, value: string, maxAgeSeconds: number, httpOnly = true): string {
  const safe = encodeURIComponent(value);
  return `${name}=${safe}; Path=/; Max-Age=${maxAgeSeconds}; SameSite=Lax; Secure${httpOnly ? "; HttpOnly" : ""}`;
}

export function getCookie(req: Request, name: string): string | null {
  const c = req.headers.get("cookie") || "";
  const parts = c.split(";").map(p => p.trim());
  for (const p of parts) {
    const [k, ...rest] = p.split("=");
    if (k === name) return decodeURIComponent(rest.join("="));
  }
  return null;
}

export function cleanSrc(raw: string | null): string {
  const s = (raw || "UNKNOWN").trim().toUpperCase().slice(0, 40);
  return s.replace(/[^A-Z0-9_:-]/g, "") || "UNKNOWN";
}

export async function sha256Hex(input: string): Promise<string> {
  const enc = new TextEncoder();
  const buf = await crypto.subtle.digest("SHA-256", enc.encode(input));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
}

export async function hmacSha256Hex(secret: string, msg: string): Promise<string> {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(msg));
  return [...new Uint8Array(sig)].map(b => b.toString(16).padStart(2, "0")).join("");
}

// Emergency, write-only logging fallback (used when Durable Object is unavailable).
// Writes to unique chunk objects to avoid overwrite risk.
type EmergencyLogType = "scans" | "inquiries" | "status_updates" | "errors";

const EMERGENCY_HEADERS: Record<EmergencyLogType, string> = {
  scans: "timestamp,src,user_agent,ip_hash\n",
  inquiries: "timestamp,name,phone,email,preferred_contact,best_time,org,event_date,guests,event_type,location,notes,booking_status,src\n",
  status_updates: "timestamp,status,src,ref_ts,ref_email,ref_phone\n",
  errors: "timestamp,route,message,detail\n",
};

function emergencyTodayKeyUTC(): string {
  const d = new Date();
  const yyyy = d.getUTCFullYear();
  const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(d.getUTCDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

// Derive the UTC day key from the first CSV cell (timestamp). Falls back to today.
function emergencyDayKeyForLine(line: string): string {
  const s = (line || "").trimStart();
  if (!s) return emergencyTodayKeyUTC();

  // Extract first CSV cell (handles optional quotes)
  let cell = "";
  if (s[0] !== '"') {
    const idx = s.indexOf(",");
    cell = (idx === -1 ? s : s.slice(0, idx)).trim();
  } else {
    for (let i = 1; i < s.length; i++) {
      const ch = s[i];
      const next = s[i + 1];
      if (ch === '"' && next === '"') {
        cell += '"';
        i++;
        continue;
      }
      if (ch === '"') break;
      cell += ch;
    }
    cell = cell.trim();
  }

  const ms = Date.parse(cell);
  if (!Number.isFinite(ms)) return emergencyTodayKeyUTC();
  const d = new Date(ms);
  const yyyy = d.getUTCFullYear();
  const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(d.getUTCDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

async function ensureEmergencyHeader(r2: R2Bucket, type: EmergencyLogType, day: string) {
  const prefix = `logs/${type}/${day}/`;
  const headerKey = prefix + (type === "errors" ? "header.log" : "header.csv");
  const exists = await r2.head(headerKey);
  if (exists) return;
  await r2.put(headerKey, EMERGENCY_HEADERS[type], {
    httpMetadata: { contentType: type === "errors" ? "text/plain; charset=utf-8" : "text/csv; charset=utf-8" },
  });
}

function emergencyChunkKey(type: EmergencyLogType, day: string): string {
  const prefix = `logs/${type}/${day}/`;
  const ts = String(Date.now()).padStart(13, "0");
  const uuid = crypto.randomUUID();
  const ext = type === "errors" ? "log" : "csv";
  return `${prefix}emergency_${ts}_${uuid}.${ext}`;
}

/**
 * Best-effort emergency append to R2 using unique chunk keys (no overwrites).
 * Intended as a fallback when DO logging is unavailable.
 */
export async function emergencyAppendR2(r2: R2Bucket, type: EmergencyLogType, line: string): Promise<void> {
  const safeLine = line.endsWith("\n") ? line : (line + "\n");
  const day = emergencyDayKeyForLine(safeLine);
  await ensureEmergencyHeader(r2, type, day);
  const key = emergencyChunkKey(type, day);
  await r2.put(key, safeLine, {
    httpMetadata: { contentType: type === "errors" ? "text/plain; charset=utf-8" : "text/csv; charset=utf-8" },
  });
}
