import { LogDO } from "./log_do";
import {
  cleanSrc,
  csvEscape,
  emergencyAppendR2,
  getCookie,
  hmacSha256Hex,
  jsonResponse,
  redirect,
  setCookieHeader,
  sha256Hex,
  textResponse,
} from "./util";

export { LogDO };

interface Env {
  R2_BUCKET: R2Bucket;
  LOG_DO: DurableObjectNamespace;
  SECRET_SALT: string;

  MAILCHANNELS_FROM: string;
  MAILCHANNELS_TO: string;
  MAILCHANNELS_API_KEY?: string;

  PUBLIC_BASE_URL: string;

  ASSETS: Fetcher;
}


function applyStaticSecurityHeaders(path: string, resp: Response): Response {
  // Clone response so we can safely set/override headers.
  const h = new Headers(resp.headers);

  // Baseline hardening (safe for static pages).
  if (!h.has("x-content-type-options")) h.set("x-content-type-options", "nosniff");
  if (!h.has("x-frame-options")) h.set("x-frame-options", "DENY");
  if (!h.has("referrer-policy")) h.set("referrer-policy", "strict-origin-when-cross-origin");
  if (!h.has("permissions-policy")) h.set("permissions-policy", "geolocation=(), microphone=(), camera=()");
  if (!h.has("cross-origin-opener-policy")) h.set("cross-origin-opener-policy", "same-origin");
  if (!h.has("cross-origin-resource-policy")) h.set("cross-origin-resource-policy", "same-origin");
  if (!h.has("strict-transport-security")) h.set("strict-transport-security", "max-age=31536000; includeSubDomains; preload");

  // CSP per page (no inline scripts/styles used).
  if (path === "/catering") {
    h.set(
      "content-security-policy",
      "default-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'; script-src 'self'; style-src 'self'"
    );
  }
  if (path === "/thank-you") {
    h.set(
      "content-security-policy",
      "default-src 'self'; base-uri 'self'; frame-ancestors 'none'; object-src 'none'; script-src 'self'; style-src 'self'"
    );
  }

  return new Response(resp.body, { status: resp.status, statusText: resp.statusText, headers: h });
}

type LogType = "scans" | "inquiries" | "status_updates" | "errors";

const MAX_BODY_BYTES = 64 * 1024; // 64KB hard cap

function logStub(env: Env) {
  const id = env.LOG_DO.idFromName("global-log-buffer");
  return env.LOG_DO.get(id);
}

// Enforce a hard body size cap. When Content-Length is absent, fall back to measuring a cloned body.
async function bodyTooLarge(req: Request): Promise<boolean> {
  const clHeader = (req.headers.get("content-length") || "").trim();
  if (clHeader) {
    const cl = parseInt(clHeader, 10) || 0;
    return cl > MAX_BODY_BYTES;
  }
  try {
    const ab = await req.clone().arrayBuffer();
    return ab.byteLength > MAX_BODY_BYTES;
  } catch {
    // Fail-open: do not block conversion if we can't measure.
    return false;
  }
}

// Fail-open logging: never block conversion; best-effort DO then emergency R2 chunk.
async function logLineSafe(env: Env, type: LogType, line: string) {
  try {
    const stub = logStub(env);
    const resp = await stub.fetch(`https://log/do?type=${type}`, { method: "POST", body: line });
    if (!resp.ok) throw new Error(`DO log failed: ${resp.status}`);
  } catch {
    try {
      await emergencyAppendR2(env.R2_BUCKET, type, line);
    } catch {
      // swallow
    }
  }
}

async function logErrorSafe(env: Env, route: string, message: string, detail: string) {
  const ts = new Date().toISOString();
  const line = `${csvEscape(ts)},${csvEscape(clip(route, 80))},${csvEscape(clip(message, 80))},${csvEscape(clip(detail, 600))}\n`;
  await logLineSafe(env, "errors", line);
}

async function checkRate(env: Env, key: string, limit: number, windowSeconds: number) {
  try {
    const stub = logStub(env);
    const resp = await stub.fetch(
      `https://log/do?action=limit&key=${encodeURIComponent(key)}&limit=${limit}&window=${windowSeconds}`,
      { method: "POST" }
    );
    if (!resp.ok) return { ok: true, remaining: 0 }; // fail-open
    return (await resp.json()) as { ok: boolean; remaining: number };
  } catch {
    return { ok: true, remaining: 0 }; // fail-open on DO outages
  }
}

async function sendMail(env: Env, subject: string, text: string) {
  // MailChannels Email API now expects an API key header.
  // Conversion remains fail-open if email is misconfigured or delivery fails.
  if (!env.MAILCHANNELS_FROM || !env.MAILCHANNELS_TO) {
    throw new Error("Mail config missing: MAILCHANNELS_FROM/MAILCHANNELS_TO");
  }
  const apiKey = (env.MAILCHANNELS_API_KEY || "").trim();
  if (!apiKey) {
    throw new Error("Mail config missing: MAILCHANNELS_API_KEY");
  }

  const payload = {
    personalizations: [{ to: [{ email: env.MAILCHANNELS_TO }] }],
    from: { email: env.MAILCHANNELS_FROM, name: "Mint Café Catering" },
    subject,
    content: [{ type: "text/plain", value: text }],
  };

  const resp = await fetch("https://api.mailchannels.net/tx/v1/send", {
    method: "POST",
    headers: { "content-type": "application/json", "X-Api-Key": apiKey },
    body: JSON.stringify(payload),
  });

  if (!resp.ok) throw new Error(`Mail send failed: ${resp.status} ${await resp.text().catch(() => "")}`);
}

function clip(s: string, max: number): string {
  const v = (s || "").toString();
  return v.length > max ? v.slice(0, max) : v;
}

function sanitizeUA(ua: string): string {
  return clip((ua || "").replace(/[\r\n\t]+/g, " ").trim(), 256);
}

function sanitizeIp(ip: string): string {
  return clip((ip || "").trim(), 64);
}

function normalizePhone(p: string): string {
  const digits = (p || "").replace(/\D+/g, "");
  if (digits.length === 11 && digits.startsWith("1")) return digits;
  if (digits.length >= 10) return digits.slice(-10);
  return digits.slice(0, 32);
}

function isValidDateKey(s: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(s);
}

function utcDateKey(offsetDays = 0): string {
  const d = new Date(Date.now() + offsetDays * 86400_000);
  const yyyy = d.getUTCFullYear();
  const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(d.getUTCDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

// Minimal CSV parser (supports quotes)
function parseCsvRows(csvText: string): Record<string, string>[] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let inQuotes = false;

  for (let i = 0; i < csvText.length; i++) {
    const ch = csvText[i];
    const next = csvText[i + 1];

    if (inQuotes) {
      if (ch === `"` && next === `"`) {
        cell += `"`;
        i++;
      } else if (ch === `"`) {
        inQuotes = false;
      } else {
        cell += ch;
      }
      continue;
    }

    if (ch === `"`) {
      inQuotes = true;
      continue;
    }
    if (ch === ",") {
      row.push(cell);
      cell = "";
      continue;
    }
    if (ch === "\n") {
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
      continue;
    }
    if (ch === "\r") continue;
    cell += ch;
  }
  if (cell.length || row.length) {
    row.push(cell);
    rows.push(row);
  }

  if (rows.length < 2) return [];
  const header = rows[0].map((h) => (h || "").trim());
  const out: Record<string, string>[] = [];
  for (let r = 1; r < rows.length; r++) {
    const arr = rows[r];
    if (!arr || arr.every((v) => !String(v || "").trim())) continue;
    const obj: Record<string, string> = {};
    for (let c = 0; c < header.length; c++) obj[header[c]] = arr[c] ?? "";
    out.push(obj);
  }
  return out;
}

async function listAllR2Keys(env: Env, prefix: string): Promise<string[]> {
  const keys: string[] = [];
  let cursor: string | undefined = undefined;
  for (;;) {
    const res = await env.R2_BUCKET.list({ prefix, cursor });
    for (const obj of res.objects) keys.push(obj.key);
    if (!res.truncated) break;
    cursor = res.cursor;
  }
  return keys;
}

async function getAssembledLogText(env: Env, type: LogType, date: string): Promise<string | null> {
  // Preferred: chunked layout
  const prefix = `logs/${type}/${date}/`;
  const headerKey = prefix + (type === "errors" ? "header.log" : "header.csv");

  const headerObj = await env.R2_BUCKET.get(headerKey);
  if (headerObj) {
    const header = await headerObj.text();
    const all = (await listAllR2Keys(env, prefix))
      .filter((k) => k !== headerKey)
      .filter((k) => k.includes("chunk_") || k.includes("emergency_"));

    // Ensure chronological ordering across both chunk_* and emergency_* objects.
    // (Lexicographic sort groups by prefix, which can interleave time.)
    const keys = all.sort((a, b) => {
      const ta = (a.match(/_(\d{13})_/) || [])[1] || "";
      const tb = (b.match(/_(\d{13})_/) || [])[1] || "";
      const na = ta ? parseInt(ta, 10) : 0;
      const nb = tb ? parseInt(tb, 10) : 0;
      if (na !== nb) return na - nb;
      return a.localeCompare(b);
    });

    let out = header;
    for (const k of keys) {
      const o = await env.R2_BUCKET.get(k);
      if (!o) continue;
      out += await o.text();
    }
    return out;
  }

  // Fallback: legacy single-file layout
  const legacyKey = type === "errors" ? `logs/${type}/${date}.log` : `logs/${type}/${date}.csv`;
  const legacyObj = await env.R2_BUCKET.get(legacyKey);
  if (!legacyObj) return null;
  return await legacyObj.text();
}

async function r2AssembledCsvOr404(env: Env, type: Exclude<LogType, "errors">, date: string, filename: string) {
  const text = await getAssembledLogText(env, type, date);
  if (!text) return new Response("Not found", { status: 404 });
  return new Response(text, {
    status: 200,
    headers: {
      "content-type": "text/csv; charset=utf-8",
      "cache-control": "no-store",
      "content-disposition": `attachment; filename=\"${filename}\"`,
    },
  });
}

async function r2AssembledTextOr404(env: Env, date: string, filename: string) {
  const text = await getAssembledLogText(env, "errors", date);
  if (!text) return new Response("Not found", { status: 404 });
  return new Response(text, {
    status: 200,
    headers: {
      "content-type": "text/plain; charset=utf-8",
      "cache-control": "no-store",
      "content-disposition": `attachment; filename=\"${filename}\"`,
    },
  });
}


export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;

    if (request.method === "GET" && path === "/health") {
      return jsonResponse({ ok: true, service: "mint-caterflow", ts: new Date().toISOString() }, 200, { "cache-control": "no-store" });
    }

    if (request.method === "GET" && path === "/health/deep") {
      try {
        const sig = (url.searchParams.get("sig") || "").toLowerCase();
        if (!sig) return textResponse("Missing sig", 400);

        const msg = "health_deep";
        const expected = await hmacSha256Hex(env.SECRET_SALT, msg);
        if (expected !== sig) {
          ctx.waitUntil(logErrorSafe(env, "/health/deep", "bad_signature", msg));
          return textResponse("Unauthorized", 401);
        }

        const probeKey = "probes/health_deep_probe.txt";
        const probeVal = `ok ${new Date().toISOString()}`;
        await env.R2_BUCKET.put(probeKey, probeVal, { httpMetadata: { contentType: "text/plain; charset=utf-8" } });
        const got = await env.R2_BUCKET.get(probeKey);
        const gotText = got ? await got.text() : "";

        const ts = new Date().toISOString();
        const line = `${csvEscape(ts)},${csvEscape("/health/deep")},${csvEscape("probe")},${csvEscape("ok")}\n`;

        let doOk = false;
        try {
          const doResp = await logStub(env).fetch(`https://log/do?type=errors`, { method: "POST", body: line });
          doOk = doResp.ok;
        } catch {
          doOk = false;
        }

        const ok = !!gotText && doOk;
        return jsonResponse({ ok, r2: { ok: !!gotText, probeKey }, durable_object: { ok: doOk }, ts }, ok ? 200 : 503, { "cache-control": "no-store" });
      } catch (err) {
        ctx.waitUntil(logErrorSafe(env, "/health/deep", "handler_failed", String(err)));
        return textResponse("Error", 500);
      }
    }

    if (request.method === "GET" && path === "/admin/flush") {
      try {
        const sig = (url.searchParams.get("sig") || "").toLowerCase();
        if (!sig) return textResponse("Missing sig", 400);

        const msg = "flush";
        const expected = await hmacSha256Hex(env.SECRET_SALT, msg);
        if (expected !== sig) {
          ctx.waitUntil(logErrorSafe(env, "/admin/flush", "bad_signature", msg));
          return textResponse("Unauthorized", 401);
        }

        let doOk = false;
        try {
          const doResp = await logStub(env).fetch("https://log/do?action=flush", { method: "POST" });
          doOk = doResp.ok;
        } catch {
          doOk = false;
        }

        return jsonResponse({ ok: doOk, flushed: doOk, ts: new Date().toISOString() }, doOk ? 200 : 503, { "cache-control": "no-store" });
      } catch (err) {
        ctx.waitUntil(logErrorSafe(env, "/admin/flush", "handler_failed", String(err)));
        return textResponse("Error", 500);
      }
    }


    if (request.method === "GET" && path === "/admin/seed-log") {
      try {
        const type = (url.searchParams.get("type") || "").toLowerCase();
        const ts = clip((url.searchParams.get("ts") || "").trim(), 40);
        const src = cleanSrc(url.searchParams.get("src"));
        const sig = (url.searchParams.get("sig") || "").toLowerCase();

        if (!type || !ts || !sig) return textResponse("Missing params", 400);
        if (type !== "scans") return textResponse("Bad type", 400);

        const msg = `seed&type=${type}&ts=${ts}&src=${src}`;
        const expected = await hmacSha256Hex(env.SECRET_SALT, msg);
        if (expected !== sig) {
          ctx.waitUntil(logErrorSafe(env, "/admin/seed-log", "bad_signature", msg));
          return textResponse("Unauthorized", 401);
        }

        const ipHash = await sha256Hex(`${env.SECRET_SALT}:seed`);
        const line = `${csvEscape(ts)},${csvEscape(src)},${csvEscape("seed")},${csvEscape(ipHash)}\n`;
        await logLineSafe(env, "scans", line);

        return jsonResponse({ ok: true, seeded: { type, ts, src }, ts: new Date().toISOString() }, 200, { "cache-control": "no-store" });
      } catch (err) {
        ctx.waitUntil(logErrorSafe(env, "/admin/seed-log", "handler_failed", String(err)));
        return textResponse("Error", 500);
      }
    }

    if (request.method === "GET" && path === "/go") {
      const src = cleanSrc(url.searchParams.get("src"));
      const ua = sanitizeUA(request.headers.get("user-agent") || "");
      const ip = sanitizeIp(request.headers.get("cf-connecting-ip") || "");
      const ipHash = await sha256Hex(`${env.SECRET_SALT}:${ip}`);

      const ts = new Date().toISOString();
      const line = `${csvEscape(ts)},${csvEscape(src)},${csvEscape(ua)},${csvEscape(ipHash)}\n`;
      ctx.waitUntil(logLineSafe(env, "scans", line));

      const cookie = setCookieHeader("cf_src", src, 60 * 60 * 24 * 7, true);
      return redirect(`/catering?src=${encodeURIComponent(src)}`, 302, { "set-cookie": cookie, "cache-control": "no-store" });
    }

    if (request.method === "GET" && path === "/call") {
      const src = cleanSrc(url.searchParams.get("src") || getCookie(request, "cf_src") || "UNKNOWN");
      const ua = sanitizeUA(request.headers.get("user-agent") || "");
      const ip = sanitizeIp(request.headers.get("cf-connecting-ip") || "");
      const ipHash = await sha256Hex(`${env.SECRET_SALT}:${ip}`);

      const ts = new Date().toISOString();
      const line = `${csvEscape(ts)},${csvEscape(`CALL_${src}`)},${csvEscape(ua)},${csvEscape(ipHash)}\n`;
      ctx.waitUntil(logLineSafe(env, "scans", line));

      return redirect("tel:+17158468805", 302, { "cache-control": "no-store" });
    }

    if (request.method === "GET" && path === "/api/status") {
      try {
        const status = (url.searchParams.get("status") || "").toLowerCase();
        const src = cleanSrc(url.searchParams.get("src") || "UNKNOWN");
        const ref_ts = (url.searchParams.get("ts") || "").slice(0, 40);
        const ref_email = (url.searchParams.get("email") || "").trim().slice(0, 160);
        const ref_phone = normalizePhone((url.searchParams.get("phone") || "").trim().slice(0, 64));
        const sig = (url.searchParams.get("sig") || "").toLowerCase();

        if (!["booked", "declined", "followup"].includes(status)) return textResponse("Bad status", 400);
        if (!ref_ts || !ref_email || !ref_phone || !sig) return textResponse("Missing params", 400);

        const msg = `status=${status}&src=${src}&ts=${ref_ts}&email=${ref_email}&phone=${ref_phone}`;
        const expected = await hmacSha256Hex(env.SECRET_SALT, msg);
        if (expected !== sig) {
          ctx.waitUntil(logErrorSafe(env, "/api/status", "bad_signature", msg));
          return textResponse("Unauthorized", 401);
        }

        const ts = new Date().toISOString();
        const line = `${csvEscape(ts)},${csvEscape(status)},${csvEscape(src)},${csvEscape(ref_ts)},${csvEscape(ref_email)},${csvEscape(ref_phone)}\n`;
        ctx.waitUntil(logLineSafe(env, "status_updates", line));

        return textResponse(`OK — marked ${status.toUpperCase()}\nYou can close this tab.`, 200, { "cache-control": "no-store" });
      } catch (err) {
        ctx.waitUntil(logErrorSafe(env, "/api/status", "handler_failed", String(err)));
        return textResponse("Error", 500);
      }
    }

    if (path === "/api/inquiry") {
      if (request.method !== "POST") return textResponse("Method Not Allowed", 405);

      try {
        if (await bodyTooLarge(request)) return textResponse("Payload too large", 413, { "cache-control": "no-store" });

        const contentType = request.headers.get("content-type") || "";
        let fields: Record<string, string> = {};

        if (contentType.includes("application/json")) {
          let body: Record<string, unknown> = {};
          try {
            body = (await request.json()) as Record<string, unknown>;
          } catch {
            return textResponse("Bad JSON", 400, { "cache-control": "no-store" });
          }
          for (const [k, v] of Object.entries(body || {})) fields[k] = (v ?? "").toString();
        } else {
          const form = await request.formData();
          for (const [k, v] of form.entries()) fields[k] = (v ?? "").toString();
        }

        // Honeypot
        const hp = (fields.website || "").trim();
        if (hp) return textResponse("Bad Request", 400, { "cache-control": "no-store" });

        // Minimal time check (human delay)
        const t0 = parseInt((fields.t || "0").toString(), 10) || 0;
        if (t0 && Date.now() - t0 < 1200) return textResponse("Bad Request", 400, { "cache-control": "no-store" });

        const src = cleanSrc(fields.src || url.searchParams.get("src") || getCookie(request, "cf_src") || "UNKNOWN");

        const ip = sanitizeIp(request.headers.get("cf-connecting-ip") || "");
        const ipHash = await sha256Hex(`${env.SECRET_SALT}:${ip}`);

        const r1 = await checkRate(env, `inq_ip:${ipHash}`, 5, 600);
        const r2 = await checkRate(env, `inq_src:${src}`, 40, 600);
        if (!r1.ok || !r2.ok) return textResponse("Too Many Requests", 429, { "cache-control": "no-store" });

        const name = (fields.name || "").trim().slice(0, 120);
        const phone = normalizePhone(fields.phone || "");
        const email = (fields.email || "").trim().slice(0, 160);

        const preferred_contact = (fields.preferred_contact || "").trim().slice(0, 16);
        const best_time = (fields.best_time || "").trim().slice(0, 16);
        const org = (fields.org || "").trim().slice(0, 120);

        const event_date = (fields.event_date || "").trim().slice(0, 32);
        const guests = (fields.guest_count || fields.guests || "").trim().slice(0, 16);
        const event_type = (fields.event_type || "").trim().slice(0, 64);
        const location = (fields.location || "").trim().slice(0, 160);
        const notes = (fields.notes || "").trim().slice(0, 2000);

        if (!name || !phone || !email) {
          return textResponse("Missing required fields: name, phone, email.", 400, { "cache-control": "no-store" });
        }

        const ts = new Date().toISOString();
        const booking_status = "pending";

        const csv =
          `${csvEscape(ts)},${csvEscape(name)},${csvEscape(phone)},${csvEscape(email)},` +
          `${csvEscape(preferred_contact)},${csvEscape(best_time)},${csvEscape(org)},` +
          `${csvEscape(event_date)},${csvEscape(guests)},${csvEscape(event_type)},${csvEscape(location)},` +
          `${csvEscape(notes)},${csvEscape(booking_status)},${csvEscape(src)}\n`;

        ctx.waitUntil(logLineSafe(env, "inquiries", csv));

        const baseUrl = env.PUBLIC_BASE_URL.replace(/\/$/, "");
        const ref_ts = ts;
        const ref_email = email;
        const ref_phone = phone;

        async function signedLink(nextStatus: "booked" | "declined" | "followup") {
          const msg = `status=${nextStatus}&src=${src}&ts=${ref_ts}&email=${ref_email}&phone=${ref_phone}`;
          const sig = await hmacSha256Hex(env.SECRET_SALT, msg);
          return `${baseUrl}/api/status?status=${encodeURIComponent(nextStatus)}&src=${encodeURIComponent(src)}&ts=${encodeURIComponent(ref_ts)}&email=${encodeURIComponent(ref_email)}&phone=${encodeURIComponent(ref_phone)}&sig=${sig}`;
        }

        const linkBooked = await signedLink("booked");
        const linkDeclined = await signedLink("declined");
        const linkFollowup = await signedLink("followup");

        const subject = `New Mint Café catering inquiry — ${name}`;
        const text =
`New catering inquiry:

Name: ${name}
Phone: ${phone}
Email: ${email}
Preferred: ${preferred_contact || "(not specified)"}
Best time: ${best_time || "(not specified)"}
Organization: ${org || "(none)"}
Event Date: ${event_date || "N/A"}
Guests (estimate): ${guests || "N/A"}
Event Type: ${event_type || "N/A"}
Location: ${location || "N/A"}
Source (QR): ${src}

Notes:
${notes || "(none)"}

One-click status update:
BOOKED:   ${linkBooked}
DECLINED: ${linkDeclined}
FOLLOWUP: ${linkFollowup}

Received at: ${ts}
`;

        ctx.waitUntil(sendMail(env, subject, text).catch((err) => logErrorSafe(env, "/api/inquiry", "email_failed", String(err))));

        return redirect("/thank-you", 303, { "cache-control": "no-store" });
      } catch (err) {
        ctx.waitUntil(logErrorSafe(env, "/api/inquiry", "handler_failed", String(err)));
        // Fail-open for conversion: show confirmation even if something unexpected happened.
        return redirect("/thank-you", 303, { "cache-control": "no-store" });
      }
    }

    if (request.method === "GET" && path === "/api/report") {
      try {
        const date = (url.searchParams.get("date") || "").trim();
        const sig = (url.searchParams.get("sig") || "").toLowerCase();
        if (!isValidDateKey(date)) return textResponse("Bad date", 400);
        if (!sig) return textResponse("Missing sig", 400);

        const msg = `report_date=${date}`;
        const expected = await hmacSha256Hex(env.SECRET_SALT, msg);
        if (expected !== sig) {
          ctx.waitUntil(logErrorSafe(env, "/api/report", "bad_signature", msg));
          return textResponse("Unauthorized", 401);
        }

        const inquiriesText = await getAssembledLogText(env, "inquiries", date);
        if (!inquiriesText) return textResponse("No inquiries for date", 404);
        const inquiries = parseCsvRows(inquiriesText);

        const nextDate = (() => {
          const d = new Date(`${date}T00:00:00.000Z`);
          d.setUTCDate(d.getUTCDate() + 1);
          const yyyy = d.getUTCFullYear();
          const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
          const dd = String(d.getUTCDate()).padStart(2, "0");
          return `${yyyy}-${mm}-${dd}`;
        })();

        const updatesAText = await getAssembledLogText(env, "status_updates", date);
        const updatesBText = await getAssembledLogText(env, "status_updates", nextDate);
        const updatesA = updatesAText ? parseCsvRows(updatesAText) : [];
        const updatesB = updatesBText ? parseCsvRows(updatesBText) : [];
        const updates = updatesA.concat(updatesB);

        const latest = new Map<string, { status: string; timestamp: string }>();
        for (const u of updates) {
          const ref_ts = (u.ref_ts || "").trim();
          const ref_email = (u.ref_email || "").trim().toLowerCase();
          const ref_phone = normalizePhone((u.ref_phone || "").trim());
          const key = `${ref_ts}|${ref_email}|${ref_phone}`;
          if (!ref_ts || !ref_email || !ref_phone) continue;

          const curTs = Date.parse((u.timestamp || "").trim()) || 0;
          const prev = latest.get(key);
          const prevTs = prev ? Date.parse(prev.timestamp) || 0 : -1;
          if (!prev || curTs >= prevTs) latest.set(key, { status: (u.status || "").trim(), timestamp: (u.timestamp || "").trim() });
        }

        let out =
          "inquiry_timestamp,name,phone,email,preferred_contact,best_time,org,event_date,guests,event_type,location,notes,src,final_status,status_updated_at\n";
        for (const i of inquiries) {
          const inquiry_ts = (i.timestamp || "").trim();
          const email = (i.email || "").trim().toLowerCase();
          const phone = normalizePhone((i.phone || "").trim());
          const key = `${inquiry_ts}|${email}|${phone}`;
          const upd = latest.get(key);

          const final_status = (upd?.status || (i.booking_status || "").trim() || "pending").toLowerCase();
          const status_updated_at = upd?.timestamp || "";

          out +=
            [
              csvEscape(inquiry_ts),
              csvEscape((i.name || "").trim()),
              csvEscape((i.phone || "").trim()),
              csvEscape((i.email || "").trim()),
              csvEscape((i.preferred_contact || "").trim()),
              csvEscape((i.best_time || "").trim()),
              csvEscape((i.org || "").trim()),
              csvEscape((i.event_date || "").trim()),
              csvEscape((i.guests || "").trim()),
              csvEscape((i.event_type || "").trim()),
              csvEscape((i.location || "").trim()),
              csvEscape((i.notes || "").trim()),
              csvEscape((i.src || "").trim()),
              csvEscape(final_status),
              csvEscape(status_updated_at),
            ].join(",") + "\n";
        }

        return new Response(out, { status: 200, headers: { "content-type": "text/csv; charset=utf-8", "cache-control": "no-store" } });
      } catch (err) {
        ctx.waitUntil(logErrorSafe(env, "/api/report", "handler_failed", String(err)));
        return textResponse("Error", 500);
      }
    }

    if (request.method === "GET" && path === "/api/report/today") {
      const date = utcDateKey(0);
      const sig = (url.searchParams.get("sig") || "").toLowerCase();
      if (!sig) return textResponse("Missing sig", 400);

      const msg = `report_date=${date}`;
      const expected = await hmacSha256Hex(env.SECRET_SALT, msg);
      if (expected !== sig) {
        ctx.waitUntil(logErrorSafe(env, "/api/report/today", "bad_signature", msg));
        return textResponse("Unauthorized", 401);
      }
      return redirect(`/api/report?date=${encodeURIComponent(date)}&sig=${sig}`, 302, { "cache-control": "no-store" });
    }

    if (request.method === "GET" && path === "/api/metrics") {
      try {
        const date = (url.searchParams.get("date") || "").trim();
        const sig = (url.searchParams.get("sig") || "").toLowerCase();
        if (!isValidDateKey(date)) return textResponse("Bad date", 400);
        if (!sig) return textResponse("Missing sig", 400);

        const msg = `metrics_date=${date}`;
        const expected = await hmacSha256Hex(env.SECRET_SALT, msg);
        if (expected !== sig) {
          ctx.waitUntil(logErrorSafe(env, "/api/metrics", "bad_signature", msg));
          return textResponse("Unauthorized", 401);
        }

        const scansText = await getAssembledLogText(env, "scans", date);
        const inquiriesText = await getAssembledLogText(env, "inquiries", date);
        const statusText = await getAssembledLogText(env, "status_updates", date);

        const scans = scansText ? parseCsvRows(scansText) : [];
        const inquiries = inquiriesText ? parseCsvRows(inquiriesText) : [];
        const statuses = statusText ? parseCsvRows(statusText) : [];

        const scansBySrc: Record<string, number> = {};
        const callsBySrc: Record<string, number> = {};
        const inquiriesBySrc: Record<string, number> = {};
        const statusByType: Record<string, number> = {};

        for (const s of scans) {
          const raw = (s.src || "").trim() || "UNKNOWN";
          if (raw.startsWith("CALL_")) {
            const src = raw.slice(5) || "UNKNOWN";
            callsBySrc[src] = (callsBySrc[src] || 0) + 1;
          } else {
            scansBySrc[raw] = (scansBySrc[raw] || 0) + 1;
          }
        }
        for (const i of inquiries) {
          const src = (i.src || "").trim() || "UNKNOWN";
          inquiriesBySrc[src] = (inquiriesBySrc[src] || 0) + 1;
        }
        for (const u of statuses) {
          const st = ((u.status || "").trim() || "unknown").toLowerCase();
          statusByType[st] = (statusByType[st] || 0) + 1;
        }

        return jsonResponse(
          {
            ok: true,
            date,
            scans_total: scans.length,
            calls_total: Object.values(callsBySrc).reduce((a, b) => a + b, 0),
            inquiries_total: inquiries.length,
            status_updates_total: statuses.length,
            scans_by_src: scansBySrc,
            calls_by_src: callsBySrc,
            inquiries_by_src: inquiriesBySrc,
            statuses_by_type: statusByType,
            ts: new Date().toISOString(),
          },
          200,
          { "cache-control": "no-store" }
        );
      } catch (err) {
        ctx.waitUntil(logErrorSafe(env, "/api/metrics", "handler_failed", String(err)));
        return textResponse("Error", 500);
      }
    }

    if (request.method === "GET" && path === "/api/logs/inquiries") {
      const date = (url.searchParams.get("date") || "").trim();
      const sig = (url.searchParams.get("sig") || "").toLowerCase();
      if (!isValidDateKey(date)) return textResponse("Bad date", 400);
      if (!sig) return textResponse("Missing sig", 400);

      const msg = `logs_inquiries_date=${date}`;
      const expected = await hmacSha256Hex(env.SECRET_SALT, msg);
      if (expected !== sig) {
        ctx.waitUntil(logErrorSafe(env, "/api/logs/inquiries", "bad_signature", msg));
        return textResponse("Unauthorized", 401);
      }
      return r2AssembledCsvOr404(env, "inquiries", date, `inquiries_${date}.csv`);
    }

    if (request.method === "GET" && path === "/api/logs/status-updates") {
      const date = (url.searchParams.get("date") || "").trim();
      const sig = (url.searchParams.get("sig") || "").toLowerCase();
      if (!isValidDateKey(date)) return textResponse("Bad date", 400);
      if (!sig) return textResponse("Missing sig", 400);

      const msg = `logs_status_updates_date=${date}`;
      const expected = await hmacSha256Hex(env.SECRET_SALT, msg);
      if (expected !== sig) {
        ctx.waitUntil(logErrorSafe(env, "/api/logs/status-updates", "bad_signature", msg));
        return textResponse("Unauthorized", 401);
      }
      return r2AssembledCsvOr404(env, "status_updates", date, `status_updates_${date}.csv`);
    }


    if (request.method === "GET" && path === "/api/logs/errors") {
      const date = (url.searchParams.get("date") || "").trim();
      const sig = (url.searchParams.get("sig") || "").toLowerCase();
      if (!isValidDateKey(date)) return textResponse("Bad date", 400);
      if (!sig) return textResponse("Missing sig", 400);

      const msg = `logs_errors_date=${date}`;
      const expected = await hmacSha256Hex(env.SECRET_SALT, msg);
      if (expected !== sig) {
        ctx.waitUntil(logErrorSafe(env, "/api/logs/errors", "bad_signature", msg));
        return textResponse("Unauthorized", 401);
      }
      return r2AssembledTextOr404(env, date, `errors_${date}.log`);
    }

    if (request.method === "GET" && path === "/api/logs/scans") {
      const date = (url.searchParams.get("date") || "").trim();
      const sig = (url.searchParams.get("sig") || "").toLowerCase();
      if (!isValidDateKey(date)) return textResponse("Bad date", 400);
      if (!sig) return textResponse("Missing sig", 400);

      const msg = `logs_scans_date=${date}`;
      const expected = await hmacSha256Hex(env.SECRET_SALT, msg);
      if (expected !== sig) {
        ctx.waitUntil(logErrorSafe(env, "/api/logs/scans", "bad_signature", msg));
        return textResponse("Unauthorized", 401);
      }
      return r2AssembledCsvOr404(env, "scans", date, `scans_${date}.csv`);
    }

    // Static assets fallback (Worker Assets)
    if (path.startsWith("/api/") || path.startsWith("/admin/") || path.startsWith("/health")) {
      return textResponse("Not Found", 404);
    }
    const assetResp = await env.ASSETS.fetch(request);
    return applyStaticSecurityHeaders(path, assetResp);
  },
} satisfies ExportedHandler<Env>;
