export interface Env {
  R2_BUCKET: R2Bucket;
  LOG_DO: DurableObjectNamespace;
  SECRET_SALT: string;
}

type LogType = "scans" | "inquiries" | "status_updates" | "errors";
type DoAction = "append" | "limit" | "flush";

type DayKey = string;

interface DayBuffer {
  scans: string[];
  inquiries: string[];
  status_updates: string[];
  errors: string[];
}

interface StoredBufferV2 {
  by_day: Record<DayKey, DayBuffer>;
}

// Legacy (pre-v2) buffer shape
interface StoredBufferV1 {
  scans: string[];
  inquiries: string[];
  status_updates: string[];
  errors: string[];
}

const DEFAULT_HEADERS: Record<LogType, string> = {
  scans: "timestamp,src,user_agent,ip_hash\n",
  inquiries: "timestamp,name,phone,email,preferred_contact,best_time,org,event_date,guests,event_type,location,notes,booking_status,src\n",
  status_updates: "timestamp,status,src,ref_ts,ref_email,ref_phone\n",
  errors: "timestamp,route,message,detail\n",
};

// Buffer guardrails (prevents DO storage runaway during prolonged R2 outages).
// Logging remains fail-open for conversion; if R2 is down long enough, we will
// drop *additional* log lines after recording an explicit overflow marker.
const MAX_BUFFER_LINES_PER_DAY_PER_TYPE = 2000;
const MAX_BUFFER_TOTAL_LINES_PER_DAY = 8000;

function overflowMarkerTimestamp(day: string): string {
  return `${day}T23:59:59.000Z`;
}

function addDropped(dayBuf: DayBuffer, type: LogType, n: number) {
  // @ts-ignore - optional meta field
  const meta = (dayBuf as any)._dropped || {};
  meta[type] = (meta[type] || 0) + n;
  // @ts-ignore
  (dayBuf as any)._dropped = meta;
}

function emitOverflowErrorLine(day: string, type: LogType, dropped: number): string {
  const ts = overflowMarkerTimestamp(day);
  return `${ts},"log_overflow","${type}","dropped=${dropped}"\n`;
}


function todayKeyUTC(): string {
  const d = new Date();
  const yyyy = d.getUTCFullYear();
  const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(d.getUTCDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function emptyDayBuffer(): DayBuffer {
  return { scans: [], inquiries: [], status_updates: [], errors: [] };
}

function dayKeyFromISO(ts: string): DayKey | null {
  const ms = Date.parse(ts);
  if (!Number.isFinite(ms)) return null;
  const d = new Date(ms);
  const yyyy = d.getUTCFullYear();
  const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(d.getUTCDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function extractFirstCsvCell(line: string): string {
  const s = (line || "").trimStart();
  if (!s) return "";
  if (s[0] !== '"') {
    const idx = s.indexOf(",");
    return (idx === -1 ? s : s.slice(0, idx)).trim();
  }
  let cell = "";
  for (let i = 1; i < s.length; i++) {
    const ch = s[i];
    const next = s[i + 1];
    if (ch === '"' && next === '"') {
      cell += '"';
      i++;
      continue;
    }
    if (ch === '"') break;
    cell += ch;
  }
  return cell.trim();
}

function dayKeyForLine(line: string): DayKey {
  const ts = extractFirstCsvCell(line);
  return dayKeyFromISO(ts) || todayKeyUTC();
}

async function ensureHeaderObject(env: Env, type: LogType, day: string) {
  const prefix = `logs/${type}/${day}/`;
  const headerKey = prefix + (type === "errors" ? "header.log" : "header.csv");
  const exists = await env.R2_BUCKET.head(headerKey);
  if (exists) return;

  await env.R2_BUCKET.put(headerKey, DEFAULT_HEADERS[type], {
    httpMetadata: { contentType: type === "errors" ? "text/plain; charset=utf-8" : "text/csv; charset=utf-8" },
  });
}

function chunkKey(type: LogType, day: string): string {
  const prefix = `logs/${type}/${day}/`;
  const ts = String(Date.now()).padStart(13, "0");
  const uuid = crypto.randomUUID();
  const ext = type === "errors" ? "log" : "csv";
  return `${prefix}chunk_${ts}_${uuid}.${ext}`;
}

async function writeChunkToR2(env: Env, type: LogType, day: string, lines: string[]) {
  if (!lines.length) return;
  await ensureHeaderObject(env, type, day);
  const key = chunkKey(type, day);
  await env.R2_BUCKET.put(key, lines.join(""), {
    httpMetadata: { contentType: type === "errors" ? "text/plain; charset=utf-8" : "text/csv; charset=utf-8" },
  });
}

export class LogDO implements DurableObject {
  private state: DurableObjectState;
  private env: Env;

  constructor(state: DurableObjectState, env: Env) {
    this.state = state;
    this.env = env;
  }

  private async load(): Promise<StoredBufferV2> {
    const v2 = await this.state.storage.get<StoredBufferV2>("buffer_v2");
    if (v2?.by_day) return v2;

    const v1 = await this.state.storage.get<StoredBufferV1>("buffer");
    const by_day: Record<DayKey, DayBuffer> = {};
    if (v1) {
      const day = todayKeyUTC();
      by_day[day] = {
        scans: v1.scans || [],
        inquiries: v1.inquiries || [],
        status_updates: v1.status_updates || [],
        errors: v1.errors || [],
      };
      await this.state.storage.put("buffer_v2", { by_day });
      await this.state.storage.delete("buffer");
      return { by_day };
    }

    return { by_day: {} };
  }

  private async save(buf: StoredBufferV2) {
    await this.state.storage.put("buffer_v2", buf);
  }

  private async checkLimit(key: string, limit: number, windowSeconds: number): Promise<{ ok: boolean; remaining: number }> {
    const now = Math.floor(Date.now() / 1000);
    const bucket = Math.floor(now / windowSeconds);
    const storageKey = `rl:${key}:${bucket}`;

    const count = (await this.state.storage.get<number>(storageKey)) || 0;
    const next = count + 1;
    await this.state.storage.put(storageKey, next, { expirationTtl: windowSeconds + 10 });

    return { ok: next <= limit, remaining: Math.max(0, limit - next) };
  }

  async alarm() {
    const buf = await this.load();

    const days = Object.keys(buf.by_day).sort();
    for (const day of days) {
      const dayBuf = buf.by_day[day] || emptyDayBuffer();

      const scans = dayBuf.scans.slice(0);
      const inquiries = dayBuf.inquiries.slice(0);
      const status_updates = dayBuf.status_updates.slice(0);
      const errors = dayBuf.errors.slice(0);

      let okScans = true,
        okInq = true,
        okStat = true,
        okErr = true;

      try {
        await writeChunkToR2(this.env, "scans", day, scans);
      } catch {
        okScans = false;
      }
      try {
        await writeChunkToR2(this.env, "inquiries", day, inquiries);
      } catch {
        okInq = false;
      }
      try {
        await writeChunkToR2(this.env, "status_updates", day, status_updates);
      } catch {
        okStat = false;
      }
      try {
        await writeChunkToR2(this.env, "errors", day, errors);
      } catch {
        okErr = false;
      }

      if (okScans) dayBuf.scans = [];
      if (okInq) dayBuf.inquiries = [];
      if (okStat) dayBuf.status_updates = [];
      if (okErr) dayBuf.errors = [];

      const allEmpty = !dayBuf.scans.length && !dayBuf.inquiries.length && !dayBuf.status_updates.length && !dayBuf.errors.length;
      if (allEmpty) delete buf.by_day[day];
      else buf.by_day[day] = dayBuf;
    }

    await this.save(buf);
  }

  async fetch(request: Request) {
    const url = new URL(request.url);
    if (request.method !== "POST") return new Response("Method Not Allowed", { status: 405 });

    const action = (url.searchParams.get("action") || "append").toLowerCase() as DoAction;

    if (action === "limit") {
      const key = (url.searchParams.get("key") || "").slice(0, 200);
      const limit = parseInt(url.searchParams.get("limit") || "0", 10);
      const windowSeconds = parseInt(url.searchParams.get("window") || "0", 10);
      if (!key || !limit || !windowSeconds) return new Response("Bad Request", { status: 400 });

      const res = await this.checkLimit(key, limit, windowSeconds);
      return new Response(JSON.stringify(res), { status: 200, headers: { "content-type": "application/json; charset=utf-8" } });
    }

    if (action === "flush") {
      await this.alarm();
      return new Response("OK", { status: 200 });
    }

    const type = (url.searchParams.get("type") || "").toLowerCase() as LogType;
    if (!["scans", "inquiries", "status_updates", "errors"].includes(type)) return new Response("Bad Request", { status: 400 });

    const line = await request.text();
    if (!line) return new Response("Bad Request", { status: 400 });

    const safeLine = line.endsWith("\n") ? line : line + "\n";
    const day = dayKeyForLine(safeLine);

    const buf = await this.load();
    const dayBuf = buf.by_day[day] || emptyDayBuffer();
    dayBuf[type].push(safeLine);

    // Guardrails: if buffers grow too large, attempt immediate flush of the hot type.
    // If R2 is still unavailable, we keep a capped buffer and record dropped counts.
    const totalLines =
      dayBuf.scans.length + dayBuf.inquiries.length + dayBuf.status_updates.length + dayBuf.errors.length;

    if (dayBuf[type].length > MAX_BUFFER_LINES_PER_DAY_PER_TYPE || totalLines > MAX_BUFFER_TOTAL_LINES_PER_DAY) {
      try {
        const lines = dayBuf[type].slice(0);
        await writeChunkToR2(this.env, type, day, lines);
        dayBuf[type] = [];
      } catch {
        // Cap: keep only first N lines and record the overflow.
        if (dayBuf[type].length > MAX_BUFFER_LINES_PER_DAY_PER_TYPE) {
          const dropped = dayBuf[type].length - MAX_BUFFER_LINES_PER_DAY_PER_TYPE;
          dayBuf[type] = dayBuf[type].slice(0, MAX_BUFFER_LINES_PER_DAY_PER_TYPE);
          addDropped(dayBuf, type, dropped);
          // record an explicit overflow marker into errors (for same day)
          dayBuf.errors.push(emitOverflowErrorLine(day, type, dropped));
          // Cap errors buffer too (avoid cascading growth)
          if (dayBuf.errors.length > MAX_BUFFER_LINES_PER_DAY_PER_TYPE) {
            const edropped = dayBuf.errors.length - MAX_BUFFER_LINES_PER_DAY_PER_TYPE;
            dayBuf.errors = dayBuf.errors.slice(0, MAX_BUFFER_LINES_PER_DAY_PER_TYPE);
            addDropped(dayBuf, "errors", edropped);
          }
        }
      }
    }

    buf.by_day[day] = dayBuf;

    await this.save(buf);

    const count = dayBuf[type].length;
    await this.state.storage.setAlarm(Date.now() + (count >= 25 ? 1000 : 30_000));
    return new Response("OK", { status: 200 });
  }
}
