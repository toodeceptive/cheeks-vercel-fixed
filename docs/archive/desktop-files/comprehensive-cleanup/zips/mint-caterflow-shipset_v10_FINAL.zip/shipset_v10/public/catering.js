(() => {
  const url = new URL(window.location.href);
  const src = (url.searchParams.get("src") || "").trim();
  const srcField = document.getElementById("srcField");
  const tField = document.getElementById("tField");

  if (src && srcField) srcField.value = src;
  if (tField) tField.value = String(Date.now());

  // Ensure all /call links preserve src for attribution.
  if (src) {
    document.querySelectorAll('a[href^="/call"]').forEach((a) => {
      try {
        const href = a.getAttribute("href") || "/call";
        const u = new URL(href, window.location.origin);
        if (!u.searchParams.get("src")) u.searchParams.set("src", src);
        a.setAttribute("href", u.pathname + (u.search ? u.search : ""));
      } catch {
        // ignore
      }
    });
  }
})();
