Mint Café — CaterFlow QR Pack

Base URL encoded: https://mint.caterflow.app

Files:
- <TAG>.png  (1200 DPI metadata, high-res)
- <TAG>.svg  (vector)
- <TAG>.pdf  (print-ready page)
- QR_SHEET_ALL.pdf (quick print sheet)
- manifest.json

Usage:
- Print PNG/PDF at 100% size (do not “fit to page” unless you confirm quiet zone remains).
- Every code points to: https://mint.caterflow.app/go?src=<TAG>
- Add new sources by editing SOURCE_REGISTRY.csv and regenerating.

Regenerate:
- Edit SOURCE_REGISTRY.csv
- Run: python scripts/qr-pack.py --base https://mint.caterflow.app --in SOURCE_REGISTRY.csv --out public/qr
