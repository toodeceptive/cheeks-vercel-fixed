# Mint Café / CaterFlow — Production Runbook

## Funnel (SSOT)
QR → `/go?src=TAG` (logs scan + sets `cf_src`) → `/catering?src=TAG` → `/api/inquiry` (logs inquiry + emails manager) → `/thank-you`

Manager status links:
- `/api/status?status=booked|declined|followup&...&sig=...` (signed) → logs status update

Exports (signed):
- `/api/report?date=YYYY-MM-DD&sig=...` (merged truth)
- `/api/logs/scans?date=...&sig=...`
- `/api/logs/inquiries?date=...&sig=...`
- `/api/logs/status-updates?date=...&sig=...`
- `/api/logs/errors?date=...&sig=...`
- `/api/metrics?date=...&sig=...` (JSON)

Health:
- `/health` (public)
- `/health/deep?sig=...` (signed, checks R2 + DO)

Ops:
- `/admin/flush?sig=...` (signed; forces DO to flush buffered lines to R2)

Debug (signed; QA-only):
- `/admin/seed-log?type=scans&ts=<ISO>&src=<SRC>&sig=...` (writes a single scan row with the provided timestamp)

---

## Reliability guarantees (pilot)
- `/go`, `/call`, and `/api/inquiry` are **fail-open** for logging/email:
  - If Durable Object logging fails, the Worker writes **emergency chunk objects** to R2.
  - If email fails, the inquiry still completes and the failure is logged.
- **No raw IP storage**: only salted hashes are stored.

---

## Required secrets / vars
Worker secrets:
- `SECRET_SALT`
- `MAILCHANNELS_FROM`
- `MAILCHANNELS_TO`
- `MAILCHANNELS_API_KEY`

Worker vars:
- `PUBLIC_BASE_URL` (e.g., `https://mintcafe.example.com`)

Bindings:
- `R2_BUCKET`
- `LOG_DO`

---

## Deploy
1) Set secrets (once per environment)
```bash
wrangler secret put SECRET_SALT
wrangler secret put MAILCHANNELS_FROM
wrangler secret put MAILCHANNELS_TO
wrangler secret put MAILCHANNELS_API_KEY
```

2) Deploy Worker
```bash
wrangler deploy
```

3) Static assets
- This repo uses **Worker Assets** (see `wrangler.toml` `[assets]`). Static pages under `public/*` are served via the `ASSETS` binding.

---

## Pilot acceptance (must-pass)
Run this after every deploy:
```bash
BASE_URL="https://<domain>" SECRET_SALT="..." DATE="YYYY-MM-DD" node scripts/qa.mjs
```
PASS-only. Any FAIL blocks promotion.

### Staging-only outage drill (DO down)
Goal: confirm conversion stays up if Durable Object is unavailable.
Method (staging only): deploy with an intentionally invalid DO binding for ~5 minutes and rerun the acceptance checks for:
- `/go` redirect works
- `/api/inquiry` still returns 303
Then revert staging to correct DO binding.

---

## Daily assembly (local)
Pull a full day bundle locally:
```bash
BASE_URL="https://<domain>" SECRET_SALT="..." DATE="YYYY-MM-DD" node scripts/assemble-day.mjs
```
Outputs:
- `artifacts/<DATE>/scans_<DATE>.csv`
- `artifacts/<DATE>/inquiries_<DATE>.csv`
- `artifacts/<DATE>/status_updates_<DATE>.csv`
- `artifacts/<DATE>/report_<DATE>.csv`
- `artifacts/<DATE>/metrics_<DATE>.json`
- `artifacts/<DATE>/errors_<DATE>.log`

---

## R2 layout
Chunked, append-safe layout (no overwrites):
```
logs/<type>/<YYYY-MM-DD>/header.csv
logs/<type>/<YYYY-MM-DD>/chunk_<ts>_<uuid>.csv
logs/<type>/<YYYY-MM-DD>/emergency_<ts>_<uuid>.csv
```
`type ∈ { scans, inquiries, status_updates }`

Day correctness:
- Lines are buffered and flushed into the day folder implied by the line’s **timestamp column** (UTC date), not by flush time.

Errors use `.log` extensions.

Legacy support:
- The system still reads `logs/<type>/<date>.csv` if present (older deployments).

---

## R2 lifecycle (recommended)
- `logs/scans/**`: 365 days
- `logs/inquiries/**`: 365 days
- `logs/status_updates/**`: 365 days
- `logs/errors/**`: 90 days
- `probes/**`: 30 days
