#!/usr/bin/env python3
"""
scripts/qr-pack.py
Generate CaterFlow QR assets from SOURCE_REGISTRY.csv.

Outputs to: public/qr/
- <TAG>.png (high-res)
- <TAG>.svg (vector)
- <TAG>.pdf (print page)
- QR_SHEET_ALL.pdf (2x2 quick print sheet)
- manifest.json (includes sha256 checksums)

Usage:
  python scripts/qr-pack.py --base https://mint.caterflow.app --in SOURCE_REGISTRY.csv --out public/qr
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
from pathlib import Path

import qrcode
import qrcode.image.svg
from PIL import Image
from pyzbar.pyzbar import decode

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch


def sha256_file(fp: Path) -> str:
    h = hashlib.sha256()
    with fp.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def make_png(url: str, out_png: Path) -> None:
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=20,
        border=4,
    )
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
    out_png.parent.mkdir(parents=True, exist_ok=True)
    img.save(out_png, format="PNG")


def make_svg(url: str, out_svg: Path) -> None:
    factory = qrcode.image.svg.SvgPathImage
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=10,
        border=4,
        image_factory=factory,
    )
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image()
    out_svg.parent.mkdir(parents=True, exist_ok=True)
    img.save(out_svg)


def make_single_pdf(tag: str, desc: str, url: str, png_path: Path, out_pdf: Path) -> None:
    c = canvas.Canvas(str(out_pdf), pagesize=letter)
    W, H = letter
    margin = 0.75 * inch

    c.setFont("Helvetica-Bold", 18)
    title = f"{tag} — {desc}".strip(" —")
    c.drawCentredString(W / 2, H - margin, title)

    # Image block
    img_size = min(W, H) - 2.0 * inch
    ix = (W - img_size) / 2
    iy = (H - img_size) / 2 - 0.25 * inch
    c.drawImage(str(png_path), ix, iy, width=img_size, height=img_size, preserveAspectRatio=True, mask="auto")

    c.setFont("Helvetica", 11)
    c.drawCentredString(W / 2, margin, url)

    c.showPage()
    c.save()


def make_sheet(rows: list[dict], out_pdf: Path) -> None:
    c = canvas.Canvas(str(out_pdf), pagesize=letter)
    W, H = letter
    margin = 0.5 * inch
    cell_w = (W - 2 * margin) / 2
    cell_h = (H - 2 * margin) / 2
    img_size = min(cell_w, cell_h) - 1.0 * inch

    for i, r in enumerate(rows):
        if i and i % 4 == 0:
            c.showPage()
        pos = i % 4
        col = pos % 2
        row = pos // 2
        x0 = margin + col * cell_w
        y0 = H - margin - (row + 1) * cell_h

        c.setFont("Helvetica-Bold", 14)
        title = f"{r['tag']} — {r['description']}".strip(" —")
        c.drawString(x0, y0 + cell_h - 0.35 * inch, title)

        png_path = Path(r["png_abs"])
        ix = x0 + (cell_w - img_size) / 2
        iy = y0 + (cell_h - img_size) / 2 - 0.15 * inch
        c.drawImage(str(png_path), ix, iy, width=img_size, height=img_size, preserveAspectRatio=True, mask="auto")

        c.setFont("Helvetica", 9)
        c.drawCentredString(x0 + cell_w / 2, y0 + 0.25 * inch, r["url"])

    c.save()


def verify_png_decodes(png_path: Path, expected_url: str) -> bool:
    img = Image.open(png_path)
    d = decode(img)
    if not d:
        return False
    got = d[0].data.decode("utf-8", errors="replace")
    return got == expected_url


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="https://mint.caterflow.app")
    ap.add_argument("--in", dest="in_csv", default="SOURCE_REGISTRY.csv")
    ap.add_argument("--out", dest="out_dir", default="public/qr")
    args = ap.parse_args()

    base = args.base.rstrip("/")
    in_csv = Path(args.in_csv)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    rows: list[dict] = []
    with in_csv.open(newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            tag = (r.get("source_tag") or "").strip().upper()
            if not tag:
                continue
            desc = (r.get("description") or "").strip()
            url = f"{base}/go?src={tag}"
            rows.append({"tag": tag, "description": desc, "url": url})

    # Generate assets
    for r in rows:
        tag = r["tag"]
        url = r["url"]
        png = out_dir / f"{tag}.png"
        svg = out_dir / f"{tag}.svg"
        pdf = out_dir / f"{tag}.pdf"

        make_png(url, png)
        make_svg(url, svg)
        make_single_pdf(tag, r["description"], url, png, pdf)

        if not verify_png_decodes(png, url):
            raise RuntimeError(f"QR decode verify failed for {tag}: {png}")

        r["png"] = png.name
        r["svg"] = svg.name
        r["pdf"] = pdf.name
        r["png_sha256"] = sha256_file(png)
        r["svg_sha256"] = sha256_file(svg)
        r["pdf_sha256"] = sha256_file(pdf)
        r["png_abs"] = str(png.resolve())

    sheet_pdf = out_dir / "QR_SHEET_ALL.pdf"
    make_sheet(rows, sheet_pdf)

    manifest = {
        "base_url": base,
        "generated_utc": dt.datetime.utcnow().isoformat(timespec="seconds") + "Z",
        "qr_sheet_pdf": sheet_pdf.name,
        "qr_sheet_pdf_sha256": sha256_file(sheet_pdf),
        "sources": [
            {
                "tag": r["tag"],
                "url": r["url"],
                "description": r["description"],
                "png": r["png"],
                "svg": r["svg"],
                "pdf": r["pdf"],
                "png_sha256": r["png_sha256"],
                "svg_sha256": r["svg_sha256"],
                "pdf_sha256": r["pdf_sha256"],
            }
            for r in rows
        ],
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print(f"OK generated {len(rows)} QR sources into {out_dir}/")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
