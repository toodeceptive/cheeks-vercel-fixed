// scripts/assemble-day.mjs
// Usage:
//   BASE_URL="https://<domain>" SECRET_SALT="..." DATE="YYYY-MM-DD" node scripts/assemble-day.mjs
// Outputs files under ./artifacts/<DATE>/

import fs from "fs/promises";
import path from "path";
import crypto from "crypto";

const BASE_URL = (process.env.BASE_URL || "").replace(/\/$/, "");
const SECRET_SALT = process.env.SECRET_SALT || "";
const DATE = process.env.DATE || ""; // YYYY-MM-DD

if (!BASE_URL || !SECRET_SALT || !DATE) {
  console.error("Missing env. Required: BASE_URL, SECRET_SALT, DATE(YYYY-MM-DD)");
  process.exit(1);
}

function hmacHex(msg) {
  return crypto.createHmac("sha256", SECRET_SALT).update(msg).digest("hex");
}

async function fetchText(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${url} => ${res.status}`);
  return await res.text();
}

async function main() {
  const outDir = path.join("artifacts", DATE);
  await fs.mkdir(outDir, { recursive: true });

  const sigInq = hmacHex(`logs_inquiries_date=${DATE}`);
  const sigScans = hmacHex(`logs_scans_date=${DATE}`);
  const sigStat = hmacHex(`logs_status_updates_date=${DATE}`);
  const sigReport = hmacHex(`report_date=${DATE}`);
  const sigMetrics = hmacHex(`metrics_date=${DATE}`);
  const sigErrors = hmacHex(`logs_errors_date=${DATE}`);

  const scans = await fetchText(`${BASE_URL}/api/logs/scans?date=${encodeURIComponent(DATE)}&sig=${sigScans}`);
  const inquiries = await fetchText(`${BASE_URL}/api/logs/inquiries?date=${encodeURIComponent(DATE)}&sig=${sigInq}`);
  const status = await fetchText(`${BASE_URL}/api/logs/status-updates?date=${encodeURIComponent(DATE)}&sig=${sigStat}`);
  const report = await fetchText(`${BASE_URL}/api/report?date=${encodeURIComponent(DATE)}&sig=${sigReport}`);
  const metrics = await fetchText(`${BASE_URL}/api/metrics?date=${encodeURIComponent(DATE)}&sig=${sigMetrics}`);
  const errors = await fetchText(`${BASE_URL}/api/logs/errors?date=${encodeURIComponent(DATE)}&sig=${sigErrors}`);

  await fs.writeFile(path.join(outDir, `scans_${DATE}.csv`), scans, "utf8");
  await fs.writeFile(path.join(outDir, `inquiries_${DATE}.csv`), inquiries, "utf8");
  await fs.writeFile(path.join(outDir, `status_updates_${DATE}.csv`), status, "utf8");
  await fs.writeFile(path.join(outDir, `report_${DATE}.csv`), report, "utf8");
  await fs.writeFile(path.join(outDir, `metrics_${DATE}.json`), metrics, "utf8");
  await fs.writeFile(path.join(outDir, `errors_${DATE}.log`), errors, "utf8");

  console.log(`Wrote: ${outDir}/`);
}

main().catch((e) => {
  console.error("FATAL", e);
  process.exit(1);
});
