#!/usr/bin/env node
/**
 * Generate QR codes from SOURCE_REGISTRY.csv.
 * Outputs:
 *   out/qr/<TAG>.png
 *   out/qr/<TAG>.svg
 * With:
 *   - ECC: H
 *   - Quiet zone (margin)
 *   - Printed short URL text under QR (same as encoded URL)
 *
 * Install:
 *   npm i qrcode csv-parse
 *
 * Usage:
 *   node scripts/qr-generate.mjs --base https://mint.caterflow.app --in SOURCE_REGISTRY.csv --out out/qr
 */

import fs from "node:fs";
import path from "node:path";
import QRCode from "qrcode";
import { parse } from "csv-parse/sync";

function arg(name, fallback = null) {
  const i = process.argv.indexOf(name);
  if (i !== -1 && process.argv[i + 1]) return process.argv[i + 1];
  return fallback;
}

const base = (arg("--base") || "https://mint.caterflow.app").replace(/\/$/, "");
const inPath = arg("--in", "SOURCE_REGISTRY.csv");
const outDir = arg("--out", "out/qr");

fs.mkdirSync(outDir, { recursive: true });

const csvText = fs.readFileSync(inPath, "utf8");
const rows = parse(csvText, { columns: true, skip_empty_lines: true });

for (const r of rows) {
  const tag = String(r.source_tag || "").trim().toUpperCase();
  if (!tag) continue;

  const url = `${base}/go?src=${encodeURIComponent(tag)}`;
  const pngPath = path.join(outDir, `${tag}.png`);
  const svgPath = path.join(outDir, `${tag}.svg`);

  // ECC + quiet zone
  const opts = {
    errorCorrectionLevel: "H",
    margin: 4, // quiet zone
    width: 1024,
  };

  const png = await QRCode.toBuffer(url, { ...opts, type: "png" });
  fs.writeFileSync(pngPath, png);

  const svg = await QRCode.toString(url, { ...opts, type: "svg" });
  // Add printed short URL text below (simple SVG footer)
  const printed = url;
  const svgWithText = svg.replace(
    /<\/svg>\s*$/i,
    `<text x="50%" y="98%" text-anchor="middle" font-size="24" font-family="Arial">${escapeXml(printed)}</text></svg>`
  );
  fs.writeFileSync(svgPath, svgWithText, "utf8");

  console.log(`OK ${tag} -> ${pngPath}, ${svgPath}`);
}

function escapeXml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}
