// scripts/qa.mjs
// Usage:
//   BASE_URL="https://<domain>" SECRET_SALT="..." DATE="YYYY-MM-DD" node scripts/qa.mjs
//
// Outputs PASS/FAIL lines and exits 0 on PASS, 1 on FAIL.

import crypto from "crypto";

const BASE_URL = (process.env.BASE_URL || "").replace(/\/$/, "");
const SECRET_SALT = process.env.SECRET_SALT || "";
const DATE = process.env.DATE || ""; // YYYY-MM-DD (UTC day key)

if (!BASE_URL || !SECRET_SALT || !DATE) {
  console.error("Missing env. Required: BASE_URL, SECRET_SALT, DATE(YYYY-MM-DD)");
  process.exit(1);
}

function hmacHex(msg) {
  return crypto.createHmac("sha256", SECRET_SALT).update(msg).digest("hex");
}

function ok(cond, msg) {
  if (!cond) throw new Error(msg);
}

async function req(path, opts = {}) {
  const url = `${BASE_URL}${path}`;
  const res = await fetch(url, { redirect: "manual", ...opts });
  const text = await res.text().catch(() => "");
  return { res, text, url };
}

function header(res, name) {
  return res.headers.get(name) || "";
}

function has(str, sub) {
  return (str || "").toLowerCase().includes((sub || "").toLowerCase());
}

async function main() {
  const results = [];
  const fail = (name, err) => results.push({ name, pass: false, detail: String(err?.message || err) });
  const pass = (name, detail = "") => results.push({ name, pass: true, detail });

  // ---------- TEST 1: /health ----------
  try {
    const { res } = await req("/health");
    ok(res.status === 200, `/health not 200 (got ${res.status})`);
    pass("HEALTH /health", "200 OK");
  } catch (e) { fail("HEALTH /health", e); }

  
  // ---------- TEST 1B: /health/deep (signed; verifies R2 + DO path) ----------
  try {
    const sig = hmacHex("health_deep");
    const { res, text } = await req(`/health/deep?sig=${sig}`);
    ok([200,503].includes(res.status), `/health/deep expected 200 or 503, got ${res.status}`);
    ok(res.status === 200, `/health/deep must be 200 for acceptance (got ${res.status}) :: ${text.slice(0, 180)}`);
    pass("HEALTH /health/deep", "200 OK");
  } catch (e) { fail("HEALTH /health/deep", e); }

// ---------- TEST 2: /go redirect + cookie + attribution in URL ----------
  const SRC = `QA_${Date.now()}`;
  try {
    const { res } = await req(`/go?src=${encodeURIComponent(SRC)}`);
    ok([301, 302, 303].includes(res.status), `/go expected redirect, got ${res.status}`);
    const loc = header(res, "location");
    ok(loc, "/go missing Location header");
    ok(loc.includes("/catering"), `/go Location not /catering: ${loc}`);
    ok(loc.includes(`src=${encodeURIComponent(SRC)}`), `/go Location missing src param: ${loc}`);

    const setCookie = header(res, "set-cookie");
    ok(setCookie, "/go missing Set-Cookie");
    ok(has(setCookie, "cf_src="), "Set-Cookie missing cf_src");
    ok(has(setCookie, "httponly"), "cf_src cookie must be HttpOnly");
    ok(has(setCookie, "secure"), "cf_src cookie must be Secure");
    ok(has(setCookie, "samesite=lax"), "cf_src cookie must be SameSite=Lax");

    pass("ATTRIBUTION /go redirect+cookie", `Location=${loc}`);
  } catch (e) { fail("ATTRIBUTION /go redirect+cookie", e); }

  // ---------- TEST 3: /catering CSP + structure ----------
  try {
    const { res, text } = await req(`/catering?src=${encodeURIComponent(SRC)}`);
    ok(res.status === 200, `/catering not 200 (got ${res.status})`);

    const csp = header(res, "content-security-policy");
    ok(csp, "Missing CSP header on /catering");
    ok(!has(csp, "unsafe-inline"), "CSP must NOT include unsafe-inline");
    ok(has(csp, "script-src") && has(csp, "'self'"), "CSP must include script-src 'self'");
    ok(has(csp, "style-src") && has(csp, "'self'"), "CSP must include style-src 'self'");

    ok(text.includes('action="/api/inquiry"'), "catering page missing inquiry form action");
    ok(text.includes('id="srcField"'), "catering page missing srcField");
    ok(text.includes('src="/catering.js"') || text.includes("catering.js"), "catering page must load /catering.js");

    pass("SECURITY /catering CSP+structure", "CSP tight + form present");
  } catch (e) { fail("SECURITY /catering CSP+structure", e); }

  // ---------- TEST 4: /api/inquiry success (303) ----------
  const EMAIL = `qa_${Date.now()}@example.com`;
  try {
    const body = new URLSearchParams({
      name: "QA Tester",
      phone: "7150000000",
      email: EMAIL,
      preferred_contact: "text",
      best_time: "morning",
      org: "QA",
      event_date: DATE,
      guest_count: "25",
      event_type: "office",
      location: "Wausau",
      notes: "QA submission",
      src: SRC,
      // The API rejects submissions that occur too quickly after page-load.
      // Simulate a human delay by backdating the hidden timer field.
      t: String(Date.now() - 2500),
      website: ""
    }).toString();

    const { res } = await req("/api/inquiry", {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body,
    });

    ok(res.status === 303, `/api/inquiry expected 303, got ${res.status}`);
    const loc = header(res, "location");
    ok(loc === "/thank-you", `/api/inquiry Location expected /thank-you, got ${loc}`);

    pass("RELIABILITY /api/inquiry submit", "303 /thank-you");
  } catch (e) { fail("RELIABILITY /api/inquiry submit", e); }

  // ---------- TEST 5: bad JSON returns 400 ----------
  try {
    const { res } = await req("/api/inquiry", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{bad json",
    });
    ok(res.status === 400, `bad JSON expected 400, got ${res.status}`);
    pass("SECURITY bad JSON => 400", "400 OK");
  } catch (e) { fail("SECURITY bad JSON => 400", e); }

  // ---------- TEST 6: oversize returns 413 ----------
  try {
    const big = "x".repeat(70_000);
    const { res } = await req("/api/inquiry", {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: `name=${big}&phone=1&email=a%40b.com`,
    });
    ok(res.status === 413, `oversize expected 413, got ${res.status}`);
    pass("SECURITY oversize => 413", "413 OK");
  } catch (e) { fail("SECURITY oversize => 413", e); }


  // ---------- TEST X: seed a scans row for an arbitrary day (verifies day-bucketing) ----------
  // This proves logs are written to the day implied by the timestamp column (not by flush time).
  const seedDay = (() => {
    const d = new Date(`${DATE}T00:00:00.000Z`);
    d.setUTCDate(d.getUTCDate() - 7);
    const yyyy = d.getUTCFullYear();
    const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
    const dd = String(d.getUTCDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  })();
  const SEED_TS = `${seedDay}T12:34:56.000Z`;
  const SEED_SRC = `SEED_${Date.now()}`;

  try {
    const sig = hmacHex(`seed&type=scans&ts=${SEED_TS}&src=${SEED_SRC}`);
    const { res, text } = await req(`/admin/seed-log?type=scans&ts=${encodeURIComponent(SEED_TS)}&src=${encodeURIComponent(SEED_SRC)}&sig=${sig}`);
    ok(res.status === 200, `/admin/seed-log expected 200, got ${res.status} :: ${text.slice(0, 180)}`);
    pass("DATA /admin/seed-log (day-bucketing)", `seedDay=${seedDay}`);
  } catch (e) { fail("DATA /admin/seed-log (day-bucketing)", e); }

  // ---------- TEST 7: force flush (signed) ----------
  try {
    const sig = hmacHex("flush");
    const { res, text } = await req(`/admin/flush?sig=${sig}`);
    ok(res.status === 200, `/admin/flush expected 200, got ${res.status} :: ${text.slice(0, 180)}`);
    pass("DATA /admin/flush", "200 OK");
  } catch (e) { fail("DATA /admin/flush", e); }

  // ---------- TEST 8: assembled inquiries log includes our row ----------
  try {
    const sig = hmacHex(`logs_inquiries_date=${DATE}`);
    const { res, text } = await req(`/api/logs/inquiries?date=${encodeURIComponent(DATE)}&sig=${sig}`);
    ok(res.status === 200, `/api/logs/inquiries not 200 (got ${res.status})`);
    ok(text.includes(EMAIL), "Assembled inquiries log missing submitted email");
    pass("DATA inquiries log assembled", "Email present");
  } catch (e) { fail("DATA inquiries log assembled", e); }


  // ---------- TEST 8b: scans log contains seeded row (arbitrary day) ----------
  try {
    const sig = hmacHex(`logs_scans_date=${seedDay}`);
    const { res, text } = await req(`/api/logs/scans?date=${encodeURIComponent(seedDay)}&sig=${sig}`);
    ok(res.status === 200, `/api/logs/scans(seedDay) not 200 (got ${res.status})`);
    ok(text.includes(SEED_SRC), "Scans log missing SEED_SRC");
    ok(text.includes(SEED_TS), "Scans log missing SEED_TS");
    pass("DATA scans log day-bucketed", `seedDay=${seedDay}`);
  } catch (e) { fail("DATA scans log day-bucketed", e); }

  // ---------- TEST 9: report includes row + final_status column ----------
  try {
    const sig = hmacHex(`report_date=${DATE}`);
    const { res, text } = await req(`/api/report?date=${encodeURIComponent(DATE)}&sig=${sig}`);
    ok(res.status === 200, `/api/report not 200 (got ${res.status})`);
    ok(text.includes(EMAIL), "Report missing submitted email");
    ok(text.toLowerCase().includes("final_status"), "Report missing final_status column");
    pass("DATA report assembled", "Row present + final_status column");
  } catch (e) { fail("DATA report assembled", e); }

  // ---------- TEST 10: metrics includes inquiry_by_src ----------
  try {
    const sig = hmacHex(`metrics_date=${DATE}`);
    const { res, text } = await req(`/api/metrics?date=${encodeURIComponent(DATE)}&sig=${sig}`);
    ok(res.status === 200, `/api/metrics not 200 (got ${res.status})`);
    const obj = JSON.parse(text);
    ok(obj?.ok === true, "metrics ok=false");
    ok((obj.inquiries_by_src?.[SRC] || 0) >= 1, `metrics missing inquiries_by_src for ${SRC}`);
    pass("ANALYTICS metrics sanity", `inquiries_by_src[${SRC}]=${obj.inquiries_by_src[SRC]}`);
  } catch (e) { fail("ANALYTICS metrics sanity", e); }

  // ---------- SUMMARY ----------
  const failed = results.filter(r => !r.pass);
  const passed = results.filter(r => r.pass);

  console.log("\n=== PILOT ACCEPTANCE RESULTS ===");
  for (const r of results) console.log(`${r.pass ? "PASS" : "FAIL"}  ${r.name}${r.detail ? " :: " + r.detail : ""}`);
  console.log(`\nPASS: ${passed.length}  FAIL: ${failed.length}`);

  process.exit(failed.length ? 1 : 0);
}

main().catch((e) => {
  console.error("FATAL", e);
  process.exit(1);
});
